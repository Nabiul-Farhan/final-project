import 'dart:convert';
import 'package:game_app/models/giveaway.dart';
import 'package:http/http.dart' as http;

Future<List<Giveaway>> fetchGiveaways() async {
  var url = Uri.parse('https://www.gamerpower.com/api/giveaways');
  var response = await http.get(url);

  var data = jsonDecode(response.body);
  final List<Giveaway> games = (data as List)
            .map((e) => Giveaway.fromJson(e as Map<String, dynamic>))
            .toList();
  return games;
}
